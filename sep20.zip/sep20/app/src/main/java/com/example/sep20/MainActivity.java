package com.example.sep20;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int myNumber=10;
        if(myNumber%2==0){
            Log.i("even", myNumber+ " is even");
        }
        else {
            Log.i("odd",myNumber+ " is odd");
        }

        int numberRows=6;
       for(int i=numberRows;i>=1;i--)
       {
           String star = "";
           for(int j=1;j<=i;j++)
           {
              star+="*";
           }
           Log.i("pyramid",star);
       }

    }
}