package com.example.test2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String myName = "Kesava";
    int hoursTravelled = 111;
    float speed = 85;
    float distance = hoursTravelled*speed;
    String abc = Float.toString(distance);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("h","instance created");
        Log.i("h",abc);
    }
    @Override
    protected void onStart() {
        super.onStart();
        Log.i("h","start");
        Toast.makeText(this,myName,Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.i("h","Resume");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("h","Restart");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.i("h","Paused");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("h","Destroy");
    }
}